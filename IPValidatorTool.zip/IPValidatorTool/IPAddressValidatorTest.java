import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class IPAddressValidatorTest {
	/** The Constant PATTERN. */
	private static final Pattern PATTERN = Pattern
			.compile("(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");

	/**
	 * The main method.
	 * 
	 * @param args
	 *            the arguments
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static void main(String[] args) throws IOException {

		FileInputStream input = null;
		FileOutputStream outputOne = null;
		FileOutputStream outputTwo = null;
		ArrayList<String> iPList = new ArrayList<String>();

		try {
			input = new FileInputStream("D:/Tefo/Unrelated/IPValidatorTool/IpAddresses.txt");
			outputOne = new FileOutputStream(
					"D:/Tefo/Unrelated/IPValidatorTool/ValidIP.txt");
			// The
			// location
			// of the output
			// files can be
			// altered
			// accordingly
			outputTwo = new FileOutputStream(
					"D:/Tefo/Unrelated/IPValidatorTool/InvalidIP.txt");
			Scanner inFile = new Scanner(input);

			while (inFile.hasNextLine()) {
				iPList.add(inFile.nextLine());
			}
			// Sorting the String of IP Addresses in descending order.
			Collections.sort(iPList, Collections.reverseOrder());
			inFile.close();

		} catch (IOException ioException) {
			ioException.printStackTrace();
		}

		if (iPList != null || !iPList.isEmpty()) {
			ipAddressValidator(outputOne, outputTwo, iPList);
		}

	}

	/**
	 * IP address Validator.
	 * 
	 * @param outputOne
	 *            the output one
	 * @param outputTwo
	 *            the output two
	 * @param iPList
	 *            the IP address list
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private static void ipAddressValidator(FileOutputStream outputOne,
			FileOutputStream outputTwo, ArrayList<String> iPList)
			throws IOException {
		String values;
		for (String temp : iPList) { // Iterate through the list of IP
										// Addresses.
			values = temp;
			// validate the list of IP address using Regex
			boolean inFileIPValid = validate(values);
			byte[] result = values.getBytes();

			if (inFileIPValid == true) {
				outputOne.write(result);
				outputOne
						.write(System.getProperty("line.separator").getBytes());
				outputOne.flush();
			} else {
				outputTwo.write(result);
				outputTwo
						.write(System.getProperty("line.separator").getBytes());
				outputTwo.flush();
			}
		}
	}

	/**
	 * Validate.
	 * 
	 * @param values
	 *            the ip address
	 * @return true, if successful
	 */
	public static boolean validate(final String values) {

		Matcher match = PATTERN.matcher(values);
		while (match.find()) {
			return PATTERN.matcher(values).matches();
		}
		return PATTERN.matcher(values).matches();
	}
}

