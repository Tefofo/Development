The IP Validator tool.

Make sure that the IPAddresses file is copied to C:\IpAddresses.txt

Unzip the file package and edit the run.bat file

in the run.bat file, edit the class path and enter the name of the class to run the program.

run the run.bat 

The IpAddresses.txt can be manipulated to enter IP addresses of choice

Two output files will be created namely ValidIP.txt and IvalidIP.txt in C:\